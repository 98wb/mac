// Empty file to work around a CMake issue.
// Somehow a C++ source file (in addition to rime_plugins_objs) is required
// by CMake (3.13.3) to create shared rime-plugins library on macOS.
