#!/bin/bash

make xcode/thirdparty
