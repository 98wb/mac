#!/bin/bash

if [[ "$TRAVIS_OS_NAME" == linux ]]; then
    echo "TODO: in this script, install the Rime plugin's dependencies for Linux"
elif [[ "$TRAVIS_OS_NAME" == osx ]]; then
    echo "TODO: in this script, install the Rime plugin's dependencies for macOS"
fi
